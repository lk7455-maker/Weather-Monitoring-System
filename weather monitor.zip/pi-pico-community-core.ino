#define POT_PIN 28  // SIG connected to GP28 (ADC2)

void setup() {
  Serial1.begin(115200);
  pinMode(LED_BUILTIN, OUTPUT);
  Serial1.println("Logic Monitor Ready!");
}

void loop() {
  int analogValue = analogRead(POT_PIN);

  Serial1.print("Value: ");
  Serial1.print(analogValue);
  Serial1.print(" | Status: ");

  if (analogValue > 510) {
    Serial1.println("HIGH");
    digitalWrite(LED_BUILTIN, HIGH); // Turn onboard LED ON
  } else {
    Serial1.println("LOW");
    digitalWrite(LED_BUILTIN, LOW);  // Turn onboard LED OFF
  }

  delay(200);
}